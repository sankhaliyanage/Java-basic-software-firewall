package test;

import org.jnetpcap.packet.JMemoryPacket;
import org.jnetpcap.packet.JPacket;
import org.jnetpcap.protocol.lan.Ethernet;
import org.jnetpcap.protocol.network.Icmp;
import org.jnetpcap.protocol.network.Ip4;
import org.jnetpcap.protocol.tcpip.Tcp;
import org.jnetpcap.protocol.tcpip.Udp;

/**
 * @author Mark Bednarczyk
 * @author Sly Technologies, Inc.
 */
public class SubHeaderAccessExample {
	public static void main(String[] args) {

		/***************************************************************************
		 * First, create our packet we will be accessing The decoded packet contents
		 * are provided above in the java type comment
		 **************************************************************************/
		JPacket packet =
		    new JMemoryPacket(Ethernet.ID,
		    /* Data acquired using JMemory.toHexdump */
		    "      16037801 16030060 089fb1f3 080045c0"
		        + "01d4e253 0000ff01 ae968397 20158397"
		        + "013b0303 27310000 00004500 01b8cb91"
		        + "4000fe11 87248397 013b8397 20151b5b"
		        + "070001a4 ae1e382b 3948e09d bee80000"
		        + "00010000 00010000 00020106 00000000"
		        + "00340000 00720000 006f0000 006f0000"
		        + "00740000 002e0000 00630000 00650000");

		/***************************************************************************
		 * Second, we pre allocate ip, icmp and destination unreachable headers that
		 * we will be working with
		 **************************************************************************/
		Ip4 ip = new Ip4();
		Icmp icmp = new Icmp(); // Need an instance so we can check on sub header
		Icmp.DestinationUnreachable unreach = new Icmp.DestinationUnreachable();

		/***************************************************************************
		 * Third, we check if headers exist and access them
		 **************************************************************************/
		if (packet.hasHeader(Ip4.ID)) { // same as hasHeader(Ip4.ID, 0)
			System.out.println("Has atleast one instance of Ip4 header");
		}

		/***************************************************************************
		 * Fourth, to check for sub headers, you need to first check and instantiate
		 * the parent header, in our case its Icmp. Once the first check succeeds
		 * only then the second check for sub header will take place. If both
		 * succeed we enter the if statement. There we access certain fields from
		 * both the parent icmp header and the child unreach header.
		 **************************************************************************/
		if (packet.hasHeader(icmp) && icmp.hasSubHeader(unreach)) {

			System.out.printf("type=%d, code=%d, reserved=%d\n",
			    icmp.type(), icmp.code(), icmp.checksum(), unreach.reserved());
		}

		/***************************************************************************
		 * Fifth, notice that we are accessing the second instance of the ip4 header
		 * found in this packet. The first instance is number 0 and the second
		 * number 1.
		 **************************************************************************/
		if (packet.hasHeader(ip, 1)) {
			System.out.println("Has a second Ip4 header too");
			System.out.printf("flags=0x%x crc=0x%x\n", ip.flags(), ip.checksum());
		}

		if (packet.hasHeader(Udp.ID)) {
			System.out.println("Has UDP header as well");
		}

		if (packet.hasHeader(Tcp.ID)) {
			System.err
			    .println("Ooops, we should not be finding a TCP header in this packet");
		}
	}
}
