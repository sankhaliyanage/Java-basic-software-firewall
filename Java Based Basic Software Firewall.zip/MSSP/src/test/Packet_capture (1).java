package test;

import java.util.ArrayList;
import java.util.List;
import org.jnetpcap.Pcap;
import org.jnetpcap.PcapIf;
import org.jnetpcap.packet.PcapPacket;
import org.jnetpcap.packet.PcapPacketHandler;
import org.jnetpcap.protocol.network.Ip4;
import java.util.Scanner;
import org.jnetpcap.protocol.network.Arp;
import org.jnetpcap.protocol.tcpip.Tcp;
import org.jnetpcap.protocol.tcpip.Udp;

public class Packet_capture {

	public static void main(String[] args) {
		List<PcapIf> all_devices = new ArrayList<PcapIf>();
                // the ArrayList all_devices Will be filled with NICs
		StringBuilder error_buffer = new StringBuilder(); 
                // error_buffer String Builder is declared for any error msgs
		int packet = Pcap.findAllDevs(all_devices, error_buffer);
                //the variable packet is assigned the function Pcap.findAllDevs with the values of variables all_devices and error_buffer
		if (packet != Pcap.OK || all_devices.isEmpty()) {
			System.out.printf("Can't read list of devices, error is %s",
					error_buffer.toString());
                //if the ArrayList is empty, an error statement is printed.
                // the error_buffer is converted to a String value before display
			return;
		}
		System.out.println("Network devices found:");
		int i = 0;
                // the NIC count is initiated.
		for (PcapIf device : all_devices) 
                {
                    String description = "";
                    description = (device.getDescription() != null) ? device.getDescription() : "No description available";
                    System.out.printf("%d: %s [%s]\n", i++, device.getName(),
					description);
		}
/* a for loop initiated for all detected NICs, where the variable description is assigned the function device.getDescription()
 if devices are detected (device.getDescription() !=null) executes the print statement with the Device MAC address and the generic name
 if any devices aren't detected, the statement executes the command to print the statement "No description detected"
                */
                final Scanner in = new Scanner (System.in);
                System.out.println("Enter the interface to capture packets :");
                int user_input = in.nextInt();
		PcapIf device = all_devices.set(user_input, null); 
                // Prompt the user to select an interface and select the respective NIC to capture packets
		System.out.printf("\nChoosing '%s' to capture packets :\n",(device.getDescription() != null) ? device.getDescription(): device.getName());
                // the details of the selected interface is displayed to the user
		int snaplength = 64 * 1024; // Capture all packets, no trucation
		int packet_capture_type = Pcap.MODE_NON_PROMISCUOUS; // capture all packets
      		int timeout =60*1000*10;               
		Pcap pcap = Pcap.openLive(device.getName(), snaplength,packet_capture_type, timeout, error_buffer);
		if (pcap == null) {
			System.out.printf("Error while opening device for capture: "
					+ error_buffer.toString());
			return; 
		}
                System.out.println("Enter the packet type to capture : \n"
                                    + "1. ARP packets \n "
                                    + "2. IP packets \n"
                                    + "3. TCP packets \n "
                                    + "4. UDP packets");
                            final int user_input_packet_type = in.nextInt();
		PcapPacketHandler<String> jpacketHandler = new PcapPacketHandler<String>() {
                    Arp arp = new Arp();
                    Ip4 Ip4 = new Ip4();
                    Tcp tcp = new Tcp();
                    Udp udp = new Udp();
			public void nextPacket(PcapPacket packet, String user) {
                            
                            
                    if ( user_input_packet_type == 1 && packet.hasHeader(arp)) {
                        System.out.println("Hardware type" + arp.hardwareType());
                        System.out.println("Protocol type" + arp.protocolType());
                        System.out.println("Packet:" + arp.getPacket());
                    } 
                    else if (user_input_packet_type == 2 && packet.hasHeader(Ip4))
                            {
                                 byte[] data = packet.getByteArray(0, packet.size()); // the package data
				byte[] Source_IP = new byte[4];
				byte[] Destination_IP = new byte[4];
				Ip4 ip = new Ip4();
				if (packet.hasHeader(ip) == false) {
					return; // Not IP packet
				}
				ip.source(Source_IP);
				ip.destination(Destination_IP);
                                String sourceIP = org.jnetpcap.packet.format.FormatUtils.ip(Source_IP);
				String destinationIP = org.jnetpcap.packet.format.FormatUtils.ip(Destination_IP);
				
				System.out.println("Source IP=" + sourceIP + 
						" Destination IP=" + destinationIP + 
						" Capture Length=" + packet.getCaptureHeader().caplen());
                            }
                    else if (user_input_packet_type == 3 && packet.hasHeader(tcp))
                    {
                        System.out.println("TCP src port:\t" + tcp.source());
				System.out.println("TCP dst port:\t" + tcp.destination());
                    }
                    else if (user_input_packet_type == 4 && packet.hasHeader(udp))
                            {
                                System.out.println("UDP src port:\t" + udp.source());
				System.out.println("UDP dst port:\t" + udp.destination());
                            }
                }
            };
				
				/* Use jNetPcap format utilities 
				
                                */
			//}
		//};
	
                pcap.loop(10000,jpacketHandler,"jnetpcap");
		//pcap.(timeout, jpacketHandler, "jnetcap");
		pcap.close();
	}
      
}
