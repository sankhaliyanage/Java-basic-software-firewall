/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package test;

/**
 *
 * @author Sankha Liyanage
 */
import java.io.IOException;
import java.util.ArrayList;  
import java.util.Date;  
import java.util.List;  
import java.util.Scanner;

//import jnetpcap API
import org.jnetpcap.Pcap;  
import org.jnetpcap.PcapIf;  
import org.jnetpcap.packet.PcapPacket;  
import org.jnetpcap.packet.PcapPacketHandler;  

// Get host IP & MAC
import java.net.InetAddress;
import java.util.Enumeration;
import java.net.NetworkInterface;


// Format data and get headers
import org.jnetpcap.packet.format.FormatUtils;
import org.jnetpcap.packet.JRegistry;
import org.jnetpcap.packet.Payload;

import org.jnetpcap.protocol.lan.Ethernet;
import org.jnetpcap.protocol.network.Icmp;

import org.jnetpcap.protocol.tcpip.Tcp;
import org.jnetpcap.protocol.tcpip.Udp;

import org.jnetpcap.protocol.network.Ip4;
public class msspproject {


//end import necessary jnetpcap libs


public static void main(String[] args) throws IOException {  
        //Fill array with NIC
        List<PcapIf> alldevs = new ArrayList<PcapIf>(); 
         // For any error msgs 
        StringBuilder errbuf = new StringBuilder(); 
  
        //Device listing on system 
        int r = Pcap.findAllDevs(alldevs, errbuf);  
        if (r == Pcap.NOT_OK || alldevs.isEmpty()) {  
            System.err.printf("Can't read list of devices, error is %s", errbuf.toString());  
            return;  
        }  
        //Print device list
        System.out.println("Network devices found:");  
  
        int i = 0;  
        for (PcapIf device : alldevs) {  
            String description =  
                (device.getDescription() != null) ? device.getDescription() : "No description available"; 
            
            System.out.printf("INT #%d: %s [%s]\n", i++, macAddress(device.getHardwareAddress()), description);  
        }  
        //End Print device list
        //Select one device
        System.out.print("\n Please select an Interface number from above to capture packets: ");
         int selectInterface = new Scanner(System.in).nextInt();
            PcapIf device = alldevs.get(selectInterface);
            
        int snaplen = 64 * 1024;           // Capture all packets, no truncation  
        int flags = Pcap.MODE_PROMISCUOUS; // capture all packets  
        int timeout = 10 * 1000;           // 10 seconds in millis  
        //End Select one device
        
        System.out.printf("\n" + device.getName() + " - %s is selected. \n",(device.getDescription() != null) ? device.getDescription()  
        : device.getName());  
        
    // Open Interface and capture packet   
    Pcap pcap = Pcap.openLive(device.getName(), snaplen, flags, timeout, errbuf);  
    
    if (pcap == null) {
        System.err.printf("Error while opening device for capture: "+ errbuf.toString());
        return;
    }
    System.out.println("'%s' is open. \n");
    // End Open Interface and capture 
    
    //Create packet handler which will receive packets
    PcapPacketHandler<String> jpacketHandler = new PcapPacketHandler<String>() {  
  
    @Override
    public void nextPacket(PcapPacket packet, String user) {   
//Printing the output string
    System.out.printf("%s caplen=%-4d len=%-4d %s\n",  
        new Date(packet.getCaptureHeader().timestampInMillis()),   
        packet.getCaptureHeader().caplen(),  // Length actually captured  
        packet.getCaptureHeader().wirelen(), // Original length   
        user                                 // User supplied object  
        );  
    
//start of recognizing packet 
	
Ip4 ip = new Ip4();
Ethernet eth = new Ethernet();
Tcp tcp = new Tcp();
Udp udp = new Udp();
Payload payload = new Payload();
byte[] sIP = new byte[4];
byte[] dIP = new byte[4];
String sourceIP="";
String destinationIP="";
String protocolName="";

sIP = packet.getHeader(ip).source();
sourceIP = org.jnetpcap.packet.format.FormatUtils.ip(sIP);
dIP = packet.getHeader(ip).destination();
destinationIP = org.jnetpcap.packet.format.FormatUtils.ip(dIP);//+++++change for tcp udp and IP
//TCP packets
if(packet.hasHeader(ip)&&packet.hasHeader(tcp)){
//Identify ports
   switch (tcp.source()) {
    case 20:protocolName="FTP";
    break;
    case 21:protocolName="FTP";
    break;
    case 22:protocolName="SSH";
    break;
    case 23:protocolName="Telnet";
    break;
    case 25:protocolName="SMTP";
    break;
    case 43:protocolName="WHOIS";
    break;
    case 49:protocolName="TACACS";
    break;
    case 53:protocolName="DNS";
    break;
    case 67:protocolName="DHCP/BOOTP Server";
    break;
    case 68:protocolName="DHCP/BOOTP Client";
    break;
    case 80:protocolName="HTTP";
    break;
    case 88:protocolName="Kerberos";
    break;
    case 110:protocolName="POP3";
    break;
    case 123:protocolName="NTP";
    break;
    case 137:protocolName="NetBIOS";
    break;
    case 139:protocolName="NetBIOS";
    break;
    case 143:protocolName="IMAP4";
    break;
    case 162:protocolName="SNMPTRAP";
    break;
    case 179:protocolName="BGP";
    break;
    case 194:protocolName="IRC";
    break;
    case 201:protocolName="AppleTalk";
    break;
    case 264:protocolName="BGMP";
    break;
    case 443:protocolName="HTTPS";
    break;
    case 464:protocolName="Kerberos";
    break;
    case 465:protocolName="SMTPS";
    break;
    case 500:protocolName="ISAKMP";
    break;
    case 513:protocolName="rlogin";
    break;
    case 514:protocolName="syslog";
    break;
    case 554:protocolName="RTSP";
    break;
    case 546:protocolName="DHCPv6 Client";
    break;
    case 547:protocolName="DHCPv6 Server";
    break;
    case 563:protocolName="NNTPS";
    break;
    case 587:protocolName="SMTP";
    break;
    case 636:protocolName="LDAPS";
    break;
    case 902:protocolName="VMware Server";
    break;
    case 989:protocolName="FTPS";
    break;
    case 990:protocolName="FTPS";
    break;
    case 993:protocolName="IMAP4S";
    break;
    case 995:protocolName="POP3S";
    break;
   }
System.out.println("Source IP: " + sourceIP + " Destination IP: " + destinationIP + " TCP Port: " + tcp.source() + " " + protocolName);
//end TCP Packets
//UDP packets
} else if (packet.hasHeader(ip)&&packet.hasHeader(udp)){
//Identify ports
switch (udp.source()) {
    case 53:protocolName="DNS";
    break;
    case 67:protocolName="DHCP/BOOTP Server";
    break;
    case 68:protocolName="DHCP/BOOTP Client";
    break;
    case 69:protocolName="TFTP";
    break;
    case 161:protocolName="SNMP";
    break;
    case 162:protocolName="SNMPTRAP";
    break;
    case 520:protocolName="RIP";
    break;
    case 521:protocolName="RIPng";
    break;
    case 546:protocolName="DHCPv6 Client";
    break;
    case 547:protocolName="DHCPv6 Server";
    break;
    case 2049:protocolName="NFS";
    break;
}
System.out.println("Source IP: " + sourceIP + " Destination IP: " + destinationIP + " UDP Port: " + udp.source() + " " + protocolName);
}//end UDP packets
//end of recognizing packet
 
    }  //End Public Void nextPacket           
    }; //End Create packet handler which will receive packets
    
    //Create loop to capture packets
    pcap.loop(100, jpacketHandler, "smthin");  
  
    // Close the pcap handle 
    pcap.close(); 
    
}//End public static void main                   
    
    
// MAC address filtering through return bit
 public static String macAddress(final byte[] mac) { 
  final StringBuilder buf = new StringBuilder(); 
  for (byte b : mac) { 
   if (buf.length() != 0) { 
    buf.append(':'); 
   } 
   if (b >= 0 && b < 16) { 
    buf.append('0'); 
   } 
   buf.append(Integer.toHexString((b < 0) ? b + 256 : b).toUpperCase()); 
  } 
 
  return buf.toString(); 
 } //End private class macAddress
}//End Public class

