package test;

import java.io.IOException;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import static test.msspproject.macAddress;
import org.jnetpcap.Pcap;
import org.jnetpcap.PcapIf;
import org.jnetpcap.packet.JMemoryPacket;
import org.jnetpcap.packet.Payload;
import org.jnetpcap.packet.PcapPacket;
import org.jnetpcap.packet.PcapPacketHandler;
import org.jnetpcap.packet.format.FormatUtils;
import org.jnetpcap.protocol.lan.Ethernet;
import org.jnetpcap.protocol.network.Arp;
import org.jnetpcap.protocol.network.Icmp;
import org.jnetpcap.protocol.network.Icmp.IcmpType;
import org.jnetpcap.protocol.tcpip.Udp;
import org.jnetpcap.protocol.voip.*;
import org.jnetpcap.protocol.network.Ip4;
import org.jnetpcap.protocol.tcpip.Tcp;

 
public class sniffer 
{
    public static void main(String[] args) throws IOException 
    {
        List<PcapIf> alldevs = new ArrayList<PcapIf>(); 
        // The list is used to display all the ports captured by the PcapIf function
       StringBuilder errbuf = new StringBuilder();
       // The StringBuilder errbuf is used to capture and display errors during the program
       int error = Pcap.findAllDevs(alldevs, errbuf);
       // This loop calculates the list of devices that can be used and prints if any errors are found
            System.out.println(error);
            if (error != Pcap.OK) 
            {
                System.err.printf("Can't read list of devices, error is %s", errbuf.toString());
                return;
                // if the 'ok' is not given by the Pcap function, the error is printed
            }
            else if (error == Pcap.OK)
            {
                System.out.println("Network devices found:"); 
                // else print the devices found
            }
            int i = 0; // Counter for the loop            
            for (PcapIf device : alldevs) 
            {
                String description = (device.getDescription() != null) ? device.getDescription() : "No description available";
                //if the description is not null, print the interface, else print 'no description available'
                System.out.printf("Interface : %d: %s [%s] %s\n", i++, device.getName(), MAC_Address(device.getHardwareAddress()),description);
            } // prints the count, device name, MAC addresss and the device description  
            
            System.out.println("choose the one device from above list of devices");
            // user prompted to select an interface from the list
            int ch = new Scanner(System.in).nextInt();
            PcapIf device =  alldevs.get(ch);// user input is read and the corresponding device is selected
            int snaplength = 64 * 1024;           // Capture all packets without truncation
            int flag = Pcap.MODE_PROMISCUOUS; // capture all packets
            int timeout = 60*60* 1000;           // 1 hour in milliseconds
            //Open the selected device to capture packets
            final Pcap pcap = Pcap.openLive(device.getName(), snaplength, flag, timeout, errbuf);
            // pcap.openLive function called with values device name, snap length, flag, timeout and the error buffer) 
            if (pcap == null) 
            {
                System.err.printf("Error while opening device for capture: "
                        + errbuf.toString());
                return; //if the pcap value is null, the statement 'error while opening devices' is printed
            }
            else if (pcap != null)
            {
                 System.out.println("device opened");
            } // if the pcap value is not null, 'device pened' statement is printed
            PcapPacketHandler<String> handler = new PcapPacketHandler<String>() 
            {    
            	Tcp tcp = new Tcp(); // tcp function is called from the native library
                Udp udp = new Udp();
                Ip4 ip = new Ip4();
                Ethernet eth = new Ethernet();
                Icmp icmp = new Icmp();
                byte[] source_IP = new byte[4];
                byte[] destination_IP = new byte[4];
                byte[] source_MAC = new byte[6];
                
                byte[] destination_MAC = new byte[6];
            	
            	public void nextPacket(PcapPacket packet, String user) 
                {  
                      if (packet.hasHeader(tcp)) 
                      {
                    	  System.out.println("A TCP packet captured:");
                          //ip address
                          source_IP = packet.getHeader(ip).source();
                          String Source_IP = org.jnetpcap.packet.format.FormatUtils.ip(source_IP);
                          destination_IP = packet.getHeader(ip).destination();
                          String Destination_IP = org.jnetpcap.packet.format.FormatUtils.ip(destination_IP);
                          //MAC address
                          source_MAC = packet.getHeader(eth).source();
                          String Source_MAC = org.jnetpcap.packet.format.FormatUtils.mac(source_MAC);
                          destination_MAC = packet.getHeader(eth).destination();
                          String Destination_MAC = org.jnetpcap.packet.format.FormatUtils.mac(destination_MAC);
                          System.out.println(" Source IP : "+Source_IP
                                           + " Destination IP : "+Destination_IP
                                           + " Source MAC Address : "+Source_MAC
                                           + " Destination MAC Address : "+Destination_MAC
                                           + " TCP port : "+tcp.source());
              /*****************************Prints the Packet Details********************************/
                          if (tcp.source() == 22 || tcp.source() == 113)
                          {  
                             if (tcp.source() == 22) // the tcp.source() funnction checks for the TCP port of the packet
                              {
                                  System.out.println("SSH packet captured");
                                  System.out.println("The captured packet redirected to :");          
                                  packet.scan(Ethernet.ID); //Start Packet Modification, scan the packet details
                                  ip = packet.getHeader(new Ip4());
                                  eth = packet.getHeader(new Ethernet());
                                  tcp = packet.getHeader(new Tcp());
                                    String destination_MAC = "2C:27:D7:A6:3A:FE";
                                    //defines the destination MAC address in String format
                                    byte [] new_destination_MAC =parseMacAddress(destination_MAC);
                                    byte[] New_Destination_MAC = destination_MAC.getBytes();
                                  eth.source(source_MAC);
                                  ip.source(source_IP); // the source IP address is copied to a byte array
                                  ip.destination(new byte[] {(byte)192,(byte)168,1,15}); // the user-defined destination IP address is written to a  byte array
                                  eth.destination(new byte [] {(byte)54,(byte)35,(byte)30,(byte)71,(byte)3D,(byte)8F});
                                  ip.checksum(ip.calculateChecksum());// the checksum is re-calculated
                                  tcp.destination(22);
                                  tcp.checksum(tcp.calculateChecksum());
                                  pcap.sendPacket(new byte [] {(byte)192,(byte)168,1,15}); //the packet is sent to the user-defined IP address
                                  packet.scan(Ethernet.ID); // End of packet modification
                                  // If the packet cannot be sent, output error
                                  if (pcap.sendPacket(packet) != Pcap.OK) 
                                    {
                                        System.err.println(pcap.getErr());
                                    }
                             }
                             else if (tcp.source() == 113)
                             {
                                  System.out.println("TCP port 113 detected  SMTP and IRC services running");
                                  System.out.println("The packet forwarded to : ");      
                                  packet.scan(Ethernet.ID); //Start Packet Modification, scan the packet details
                                  ip = packet.getHeader(new Ip4());
                                  eth = packet.getHeader(new Ethernet());
                                  tcp = packet.getHeader(new Tcp());
                                  eth.source(source_MAC);
                                  ip.source(source_IP); // the source IP address is copied to a byte array
                                  ip.destination(new byte[] {(byte)192,(byte)168,1,15}); // the user-defined destination IP address is written to a  byte array
                                  eth.destination(new byte [] {(byte)54,(byte)35,(byte)30,(byte)71,(byte)3D,(byte)8F});
                                  ip.checksum(ip.calculateChecksum());// the checksum is re-calculated
                                  tcp.destination(113);
                                  tcp.checksum(tcp.calculateChecksum());
                                  pcap.sendPacket(new byte [] {(byte)192,(byte)168,1,12}); //the packet is sent to the user-defined IP address
                                  packet.scan(Ethernet.ID); // End of packet modification
                                  // If the packet cannot be sent, output error
                                  if (pcap.sendPacket(packet) != Pcap.OK) 
                                    {
                                        System.err.println(pcap.getErr());
                                    }
                             }
                      } 
                      else if (tcp.source() == 80)
                      {
                          System.out.println("TCP port 80 detected.");
                          System.out.println("The packet redirected to the web-server");
                          packet.scan(Ethernet.ID); //Start Packet Modification, scan the packet details
                          ip = packet.getHeader(new Ip4());
                          eth = packet.getHeader(new Ethernet());
                          tcp = packet.getHeader(new Tcp());
                          eth.source(source_MAC);
                          ip.source(source_IP); // the source IP address is copied to a byte array
                          ip.destination(new byte[] {(byte)192,(byte)168,1,12}); // the user-defined destination IP address is written to a  byte array
                          eth.destination(new byte [] {(byte)54,(byte)35,(byte)30,(byte)71,(byte)3D,(byte)8F});
                          ip.checksum(ip.calculateChecksum());// the checksum is re-calculated
                          tcp.destination(22);
                          tcp.checksum(tcp.calculateChecksum());
                          pcap.sendPacket(new byte [] {(byte)192,(byte)168,1,12}); //the packet is sent to the user-defined IP address
                          packet.scan(Ethernet.ID); // End of packet modification
                          // If the packet cannot be sent, output error
                           if (pcap.sendPacket(packet) != Pcap.OK) 
                           {
                              System.err.println(pcap.getErr());
                           }
                          }
                          else if (tcp.source() == 23)
                          {
                              System.out.println("Telnet packet captured");
                              System.out.println("The Destination selected is : "+Destination_IP); 
                              String Source_Sub_String1 = Source_IP.substring(0,10);
                              if ("192.168.1.".equals(Source_Sub_String1) )
                              {
                                System.out.println("Telnet connection initialted with the external host");
                              }
                              //if the telnet request comes from external host, the packet is redirected.
                              else 
                              {
                                 packet.scan(Ethernet.ID); //Start Packet Modification, scan the packet details
                                  ip = packet.getHeader(new Ip4());
                                  eth = packet.getHeader(new Ethernet());
                                  tcp = packet.getHeader(new Tcp());
                                  eth.source(source_MAC);
                                  ip.source(source_IP); // the source IP address is copied to a byte array
                                  ip.destination(new byte[] {(byte)192,(byte)168,1,12}); // the user-defined destination IP address is written to a  byte array
                                  eth.destination(new byte [] {(byte)54,(byte)35,(byte)30,(byte)71,(byte)3D,(byte)8F});
                                  ip.checksum(ip.calculateChecksum());// the checksum is re-calculated
                                  tcp.destination(23);
                                  tcp.checksum(tcp.calculateChecksum());
                                  pcap.sendPacket(new byte [] {(byte)192,(byte)168,1,12}); //the packet is sent to the user-defined IP address
                                  packet.scan(Ethernet.ID); // End of packet modification
                                  // If the packet cannot be sent, output error
                                  if (pcap.sendPacket(packet) != Pcap.OK) 
                                    {
                                        System.err.println(pcap.getErr());
                                    }
                              }   
                          }
                          else if (tcp.source() == 25)
                          {
                              System.out.println("SMTP packets captured");                                    
                              String Destination_Sub_String_Internal_network = Destination_IP.substring(0, 12); 
                              String Source_Sub_String_Internal_network = Source_IP.substring(0, 10);
                              String Destination_Sub_String_External_network = Destination_IP.substring(0, 12);
                              String Source_Sub_String_External_network = Source_IP.substring(0, 12);
                               if ("192.168.1.30".equals(Destination_Sub_String_Internal_network) || "192.168.1".equals(Source_Sub_String_Internal_network) || "192.168.1.30".equals(Destination_Sub_String_Internal_network)|| "192.168.1".equals(Source_Sub_String_Internal_network))
                               {
                                   System.out.println("The mail passed to the mail server");
                               }
                               else if ("192.168.1.30".equals(Destination_Sub_String_External_network) || "".equals(Source_Sub_String_External_network) || "192.168.1.30".equals(Source_Sub_String_External_network) || "".equals(Destination_Sub_String_External_network))
                               {
                                   System.out.println("The mail passed to the mail server");
                               }
                             else
                               {
                                  packet.scan(Ethernet.ID); //Start Packet Modification, scan the packet details
                                  ip = packet.getHeader(new Ip4());
                                  eth = packet.getHeader(new Ethernet());
                                  tcp = packet.getHeader(new Tcp());
                                  eth.source(source_MAC);
                                  ip.source(source_IP); // the source IP address is copied to a byte array
                                  ip.destination(new byte[] {(byte)192,(byte)168,1,12}); // the user-defined destination IP address is written to a  byte array
                                  eth.destination(new byte [] {(byte)54,(byte)35,(byte)30,(byte)71,(byte)3D,(byte)8F});
                                  ip.checksum(ip.calculateChecksum());// the checksum is re-calculated
                                  tcp.destination(25);
                                  tcp.checksum(tcp.calculateChecksum());
                                  pcap.sendPacket(new byte [] {(byte)192,(byte)168,1,12}); //the packet is sent to the user-defined IP address
                                  packet.scan(Ethernet.ID); // End of packet modification
                                  // If the packet cannot be sent, output error
                                  if (pcap.sendPacket(packet) != Pcap.OK) 
                                    {
                                        System.err.println(pcap.getErr());
                                    } 
                              }
                          }
                              
                      }
                      //end of tcp packet capture
                         else if (packet.hasHeader(udp))
                          {
                            //IP section of a message
                            System.out.println("UDP packet has been captured");
                            source_IP = packet.getHeader(ip).source();
                            String Source_IP = org.jnetpcap.packet.format.FormatUtils.ip(source_IP);
                            destination_IP = packet.getHeader(ip).destination();
                            String Destination_IP = org.jnetpcap.packet.format.FormatUtils.ip(destination_IP);
                            //MAC address section of a message
                            source_MAC = packet.getHeader(eth).source();
                            String Source_MAC = org.jnetpcap.packet.format.FormatUtils.mac(source_MAC);
                            destination_MAC = packet.getHeader(eth).destination();
                            String Destination_MAC = org.jnetpcap.packet.format.FormatUtils.mac(destination_MAC);
                            System.out.println(" Source IP : "+Source_IP
                                             + " Destination IP : "+Destination_IP
                                             + " Source MAC Address : "+Source_MAC
                                             + " Destination MAC Address : "+Destination_MAC
                                             + " UDP port : "+udp.source());
                          if (udp.source() == 53)
                          {
                              System.out.println("A DNS Server query packet captured"); 
                          }
                          else if (udp.source() !=53)
                          {
                           packet.scan(Ethernet.ID); //Start Packet Modification, scan the packet details
                           ip = packet.getHeader(new Ip4());
                           eth = packet.getHeader(new Ethernet());
                           udp = packet.getHeader(new Udp());
                           eth.source(source_MAC);
                           ip.source(source_IP); // the source IP address is copied to a byte array
                           ip.destination(new byte[] {(byte)192,(byte)168,1,12}); // the user-defined destination IP address is written to a  byte array
                           eth.destination(new byte [] {(byte)54,(byte)35,(byte)30,(byte)71,(byte)3D,(byte)8F});
                           ip.checksum(ip.calculateChecksum());// the checksum is re-calculated
                           //  udp.checksum(udp.calculateChecksum());
                           pcap.sendPacket(new byte [] {(byte)192,(byte)168,1,12}); //the packet is sent to the user-defined IP address
                           packet.scan(Ethernet.ID); // End of packet modification
                           // If the packet cannot be sent, output error
                           if (pcap.sendPacket(packet) != Pcap.OK) 
                           {
                             System.err.println(pcap.getErr());
                           } 
                         }
                       }
                         // end of udp packet processing
                        else if(packet.hasHeader(icmp)) 
                        {
                           System.out.println("An ICMP packet has been captured:");
                           //IP layer of a message
                           source_IP = packet.getHeader(ip).source();
                           String Source_IP = org.jnetpcap.packet.format.FormatUtils.ip(source_IP);
                           destination_IP = packet.getHeader(ip).destination();
                           String Destination_IP = org.jnetpcap.packet.format.FormatUtils.ip(destination_IP);
                           //MAC address layer of a message
                           source_MAC = packet.getHeader(eth).source();
                           String Source_MAC = org.jnetpcap.packet.format.FormatUtils.mac(source_MAC);
                           destination_MAC = packet.getHeader(eth).destination();
                           String Destination_MAC = org.jnetpcap.packet.format.FormatUtils.mac(destination_MAC);
                           System.out.println(" Source IP : "+Source_IP
                                            + " Destination IP : "+Destination_IP
                                            + " Source MAC Address : "+Source_MAC
                                            + " Destination MAC Address : "+Destination_MAC 
                                            + "ICMP packet type : " +icmp.typeDescription());
                           // destination unreachable
                           Icmp.DestinationUnreachable unreachable_destination = new Icmp.DestinationUnreachable();
                           icmp.hasSubHeader(unreachable_destination);
                           // end of destination unreachable
                           // echo request
                           Icmp.EchoRequest echo_request = new Icmp.EchoRequest();
                           icmp.hasSubHeader(echo_request);
                           // end of echo request
                           //echo reply
                           Icmp.EchoReply echo_reply = new Icmp.EchoReply();
                           icmp.hasSubHeader(echo_reply);
                           // end of echo reply
                           //ICMP rediect
                           Icmp.Redirect redirect = new Icmp.Redirect();
                           icmp.hasSubHeader(redirect);
                           // end of ICMP redirect
                         if (icmp.hasSubHeader(unreachable_destination))
                         {
                             System.out.println("ICMP Destination unreachable packet captured" );
                         }
                         else if (icmp.hasSubHeader(echo_request))
                         {
                           System.out.println("ICMP echo request packet captured");
                           packet.scan(Ethernet.ID); //Start Packet Modification, scan the packet details
                           icmp = packet.getHeader(new Icmp());
                           eth = packet.getHeader(new Ethernet());
                           eth.source(source_MAC);
                           ip.source(source_IP); // the source IP address is copied to a byte array
                           ip.destination(new byte[] {(byte)192,(byte)168,1,12}); // the user-defined destination IP address is written to a  byte array
                           eth.destination(new byte [] {(byte)54,(byte)35,(byte)30,(byte)71,(byte)3D,(byte)8F});
                           ip.checksum(ip.calculateChecksum());// the checksum is re-calculated
                           pcap.sendPacket(new byte [] {(byte)192,(byte)168,1,12}); //the packet is sent to the user-defined IP address
                           packet.scan(Ethernet.ID); // End of packet modification
                           // If the packet cannot be sent, output error
                           if (pcap.sendPacket(packet) != Pcap.OK) 
                           {
                             System.err.println(pcap.getErr());
                           } 
                             
                            
                             packet.scan(Ethernet.ID); //Start Packet Modification, scan the packet details
                             icmp = packet.getHeader(new Icmp());
                             ip = packet.getHeader(new Ip4());
                            //Editing the Ip layer
                             eth = packet.getHeader(new Ethernet());
                             ip.source(source_IP); 
                             eth.source(source_MAC);
                             // the modified MAC address
                             eth.destination(new byte []{(byte)54,(byte)35,(byte)30,(byte)71,(byte)3D,(byte)8F});
                             ip.destination(new byte[] {(byte)192,(byte)168,0,2});
                             ip.checksum(ip.calculateChecksum());
                             pcap.sendPacket(new byte [] {(byte)192,(byte)168,0,2}); //the IP address the packet to be forwarded   
                             packet.scan(Ethernet.ID); // End of packet modification 
                         }
                        
                      else if (icmp.hasSubHeader(echo_reply))
                      {
                          System.out.println("ICMP echo reply packet captured");
                      }        
                      else if (icmp.hasSubHeader(redirect))
                      {
        
                        System.out.println("ICMP redirect packet captured");
                      }
                      // end of icmp packet processing
                      }  
                   } 
            	} ;
          pcap.loop(100000, handler,null);
            //Close the pcap
            pcap.close();
    }
    
    public static String MAC_Address (byte [] mac_address)
    {
        StringBuilder buffer = new StringBuilder(); 
        for (byte byte_size : mac_address) 
        { 
            if (buffer.length() != 0) 
            { 
                buffer.append(':'); 
            } 
            if (byte_size >= 0 && byte_size < 16) 
         { 
                buffer.append('0'); 
            } 
        buffer.append(Integer.toHexString((byte_size < 0) ? byte_size + 256 : byte_size).toUpperCase()); 
        } 
 
  return buffer.toString(); 
    }
    
    public static byte[] parseMacAddress(String MAC_Address) {
        String[] MAC_to_bytes = MAC_Address.split(":");
        byte[] parsed_MAC = new byte[MAC_to_bytes.length];

        for (int x = 0; x < MAC_to_bytes.length; x++) {
            BigInteger temp = new BigInteger(MAC_to_bytes[x], 16);
            byte[] raw = temp.toByteArray();
            parsed_MAC[x] = raw[raw.length - 1];
        }
        return parsed_MAC;
    }
}
