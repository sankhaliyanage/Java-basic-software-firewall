/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package test;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import org.jnetpcap.Pcap;
import org.jnetpcap.PcapIf;
import org.jnetpcap.packet.PcapPacket;
import org.jnetpcap.packet.PcapPacketHandler;
import org.jnetpcap.protocol.network.Ip4;
import org.jnetpcap.protocol.tcpip.Tcp;

/**
 *
 * @author Sankha Liyanage
 */
public class Sample_code {
    
	public static void main(String[] args) {
		List<PcapIf> all_devices = new ArrayList<PcapIf>();
                // the ArrayList all_devices Will be filled with NICs
		StringBuilder error_buffer = new StringBuilder(); 
                // error_buffer String Builder is declared for any error msgs
		int packet = Pcap.findAllDevs(all_devices, error_buffer);
                //the variable packet is assigned the function Pcap.findAllDevs with the values of variables all_devices and error_buffer
		if (packet != Pcap.OK || all_devices.isEmpty()) {
			System.out.printf("Can't read list of devices, error is %s",
					error_buffer.toString());
                //if the ArrayList is empty, an error statement is printed.
                // the error_buffer is converted to a String value before display
			return;
		}
		System.out.println("Network devices found:");
		int i = 0;
                // the NIC count is initiated.
		for (PcapIf device : all_devices) 
                {
                    String description = "";
                    description = (device.getDescription() != null) ? device.getDescription() : "No description available";
                    System.out.printf("%d: %s [%s]\n", i++, device.getName(),
					description);
		}
/* a for loop initiated for all detected NICs, where the variable description is assigned the function device.getDescription()
 if devices are detected (device.getDescription() !=null) executes the print statement with the Device MAC address and the generic name
 if any devices aren't detected, the statement executes the command to print the statement "No description detected"
                */
                Scanner in = new Scanner (System.in);
                System.out.println("Enter the interface to capture packets :");
                int user_input = in.nextInt();
		PcapIf device = all_devices.set(user_input, null); 
                // Prompt the user to select an interface and select the respective NIC to capture packets
		System.out.printf("\nChoosing '%s' to capture packets :\n",(device.getDescription() != null) ? device.getDescription(): device.getName());
                // the details of the selected interface is displayed to the user
		int snaplen = 64 * 1024; // Capture all packets, no trucation
		int flags = Pcap.MODE_PROMISCUOUS; // capture all packets
		int timeout = 10 * 1000; // 10 seconds in millis
		Pcap pcap = Pcap.openLive(device.getName(), snaplen, flags, timeout, error_buffer);
		if (pcap == null) {
			System.err.printf("Error while opening device for capture: "
					+ error_buffer.toString());
			return;
		}
		PcapPacketHandler<String> jpacketHandler = new PcapPacketHandler<String>() {
			public void nextPacket(PcapPacket packet, String user) {
				byte[] data = packet.getByteArray(0, packet.size()); // the package data
				byte[] srcIP = new byte[4];
				byte[] dstIP = new byte[4];
                                
                                byte [] sourceMAC = new byte [6];
                                byte [] destinationMAC = new byte [6];
                                
                                Tcp tcp = new Tcp();
                                
				Ip4 ip = new Ip4();
				if (packet.hasHeader(ip) == false) {
					return; // Not IP packet
				}
				ip.source(srcIP);
				ip.destination(dstIP);
                             
				/* Use jNetPcap format utilities */
				String sourceIP = org.jnetpcap.packet.format.FormatUtils.ip(srcIP);
				String destinationIP = org.jnetpcap.packet.format.FormatUtils.ip(dstIP);
				String Source_MAC = org.jnetpcap.packet.format.FormatUtils.mac(sourceMAC);
                                String Destination_MAC = org.jnetpcap.packet.format.FormatUtils.mac(destinationMAC);
				System.out.println("sourceIP=" + sourceIP + 
						" destinationIP=" + destinationIP + 
                                                "Source MAC : " + Source_MAC +
                                                "Destination MAC : " + Destination_MAC +
						" TCP port :" + tcp.source());
			}
		};
		// capture first 10 packages
		pcap.loop(10, jpacketHandler, "jNetPcap");
		pcap.close();
	}
}


