package mssp;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import org.jnetpcap.Pcap;
import org.jnetpcap.PcapDumper;
import org.jnetpcap.PcapHandler;
import org.jnetpcap.PcapIf;
import org.jnetpcap.packet.PcapPacket;
import org.jnetpcap.packet.PcapPacketHandler;
import org.jnetpcap.protocol.lan.Ethernet;
import org.jnetpcap.protocol.network.Icmp;
import org.jnetpcap.protocol.tcpip.Udp;
import org.jnetpcap.protocol.network.Ip4;
import org.jnetpcap.protocol.tcpip.Tcp;

 
public class PcapDumperExample {
    public static void main(String[] args) throws IOException {
        List<PcapIf> alldevs = new ArrayList<PcapIf>(); 
        //builds a List with available lists
       StringBuilder errbuf = new StringBuilder();
       int error = Pcap.findAllDevs(alldevs, errbuf);
            System.out.println(error);//if no devices found, print an error
            if (error != Pcap.OK) {
                System.err.printf("Can't read list of devices, error is %s", errbuf.toString());
                return;
            }
            //if network devices found, print the ereor statement. else print the available interfaces
            else if (error == Pcap.OK){
                System.out.println("Network devices found:"); 
            }
            int i = 0; // Counter for the loop            
            for (PcapIf device : alldevs){
                String description = (device.getDescription() != null) ? device.getDescription() : "No description available";
                System.out.printf("Interface : %d: %s [%s] %s\n", i++, device.getName(), MAC_Address_to_String(device.getHardwareAddress()),description);
            }
            //print the device name, MAC address and device description
            System.out.println("choose the one device from above list of devices");
            int UI_to_choose_an_interface = new Scanner(System.in).nextInt();
            PcapIf device =  alldevs.get(UI_to_choose_an_interface);// user input is read and the corresponding device is selected
            int snaplength = 64 * 1024;// Capture all packets without truncation
            int flag = Pcap.MODE_PROMISCUOUS; // capture all packets arriving at the interface
            int timeout = 60*60* 1000;// 1 hour in milliseconds
    
            final Pcap pcap = Pcap.openLive(device.getName(), snaplength, flag, timeout, errbuf);
            if (pcap == null){ //print an error if the selected interface cannot be opened
                System.err.printf("Error while opening device for capture: "
                        + errbuf.toString());
                return; 
            }
            else if (pcap != null){
                 System.out.println("device opened");
            } // if the pcap value is not null, 'device opened' statement is printed
             //Open the selected device to capture packets
            /*****************************************************************************************************/
            //Pcap dumper
            String output_file = "temp-capture-file.cap";  
            PcapDumper dumper = pcap.dumpOpen(output_file); // output file  
            PcapHandler<PcapDumper> dumpHandler = new PcapHandler<PcapDumper>() {  
            public void nextPacket(PcapDumper dumper, long seconds, int useconds,  
            int capture_length, int length, ByteBuffer buffer) {  
        dumper.dump(seconds, useconds, capture_length, length, buffer);  
      }  
    }; //runs the dump file capture 
 /*****************************************************************************************************/

            PcapPacketHandler<String> handler = new PcapPacketHandler<String>(){    
            	Tcp tcp = new Tcp();//native functions of tcp, udp,ip,ethernet and icmp are called
                Udp udp = new Udp();
                Ip4 ip = new Ip4();
                Ethernet eth = new Ethernet();
                Icmp icmp = new Icmp();
                //TCP,UDP, IP, Ethernet and ICMP functions called from the native library
                byte[] source_IP = new byte[4];
                byte[] destination_IP = new byte[4];
                //byte arrays of size 4 declared with source_IP and destination_IP
                byte[] source_MAC = new byte[6];
                byte[] destination_MAC = new byte[6];
                //byte arrays of size 6 declared with source_MAC and destination_MAC
            	public void nextPacket(PcapPacket packet, String user){  
                      if (packet.hasHeader(tcp)){
                    	  System.out.println("A TCP packet captured:");
                          //source and destination ip address declaration
                          source_IP = packet.getHeader(ip).source();
                          String Source_IP = org.jnetpcap.packet.format.FormatUtils.ip(source_IP);
                          destination_IP = packet.getHeader(ip).destination();
                          String Destination_IP = org.jnetpcap.packet.format.FormatUtils.ip(destination_IP);
                          //source and destination MAC address declaration
                          source_MAC = packet.getHeader(eth).source();
                          String Source_MAC = org.jnetpcap.packet.format.FormatUtils.mac(source_MAC);
                          destination_MAC = packet.getHeader(eth).destination();
                          String Destination_MAC = org.jnetpcap.packet.format.FormatUtils.mac(destination_MAC);
                          System.out.println(" Source IP : "+Source_IP
                                           + " Destination IP : "+Destination_IP
                                           + " Source MAC Address : "+Source_MAC
                                           + " Destination MAC Address : "+Destination_MAC
                                           + " TCP port : "+tcp.source());
              /*****************************Prints the Packet Details********************************/
                          if (tcp.source() == 22 || tcp.source() == 113){  
                              /*****************************TCP port 22 scan initiation********************************/
                             if (tcp.source() == 22){ // the tcp.source() function checks for the TCP port of the packet
                                  System.out.println("SSH packet captured");
                                    //Start Packet Modification, scan the packet details    
                                  packet.scan(Ethernet.ID); 
                                  ip = packet.getHeader(new Ip4());
                                  eth = packet.getHeader(new Ethernet());
                                  tcp = packet.getHeader(new Tcp());
                                  eth.source(source_MAC);
                                  ip.source(source_IP); 
                                   // the source IP and MAC address is copied to a byte array
                                  eth.destination(new byte [] {(byte)54,(byte)35,(byte)30,(byte)71,(byte)3D,(byte)8F}); //the destination MAC iis written to the packet
                                  // the user-defined destination IP address is written to a  byte array
                                  ip.destination(new byte[] {(byte)192,(byte)168,1,3});  
                                  String New_Destination_IP = org.jnetpcap.packet.format.FormatUtils.ip(ip.destination());
                                  String New_Ethernet_Address = org.jnetpcap.packet.format.FormatUtils.mac(eth.destination());
                                  ip.checksum(ip.calculateChecksum());//ip checksum re-calculation
                                  tcp.destination(22);
                                  tcp.checksum(tcp.calculateChecksum());//ip checksum re-calculation
                                  pcap.sendPacket(new byte [] {(byte)192,(byte)168,1,3}); 
                                  //the packet is sent to the user-defined IP address
                                  packet.scan(Ethernet.ID); // End of packet modification
                                  // If the packet cannot be sent, output error
                                  System.out.println("The captured packet redirected to :"+New_Destination_IP+"" +New_Ethernet_Address);    
                                  if (pcap.sendPacket(packet) != Pcap.OK){
                                        System.err.println(pcap.getErr());//print error if the pcap fails
                                    }
                             }
/*****************************TCP port 22 scan end********************************/
/*****************************TCP port 113 scan initiation********************************/
                             else if (tcp.source() == 113){
                                  System.out.println("TCP port 113 detected  SMTP and IRC services running");
                                  System.out.println("The packet forwarded to : ");      
                                  packet.scan(Ethernet.ID); //Start Packet Modification, scan the packet details
                                  ip = packet.getHeader(new Ip4());
                                  eth = packet.getHeader(new Ethernet());
                                  tcp = packet.getHeader(new Tcp());
                                  eth.source(source_MAC);
                                  ip.source(source_IP);
                                  ip.destination(new byte[] {(byte)192,(byte)168,0,3}); // the user-defined destination IP address is written to a  byte array
                                  eth.destination(new byte [] {(byte)54,(byte)35,(byte)30,(byte)71,(byte)3D,(byte)8F});
                                  ip.checksum(ip.calculateChecksum());// ip checksum re-calculation
                                  tcp.destination(113);
                                  tcp.checksum(tcp.calculateChecksum());
                                  pcap.sendPacket(new byte [] {(byte)192,(byte)168,0,3}); //the packet is sent to the user-defined IP address
                                  packet.scan(Ethernet.ID); // End of packet modification
                                  // If the packet cannot be sent, output error
                                  if (pcap.sendPacket(packet) != Pcap.OK) {
                                        System.err.println(pcap.getErr());
                                    }
                             }
                      }
/*****************************TCP port 113 scan end********************************/
/*****************************TCP port 80 scan initiation********************************/
                      else if (tcp.source() == 80){
                          System.out.println("TCP port 80 detected.");
                          System.out.println("The packet redirected to the web-server");
                          packet.scan(Ethernet.ID); //Start Packet Modification, scan the packet details
                          ip = packet.getHeader(new Ip4());
                          eth = packet.getHeader(new Ethernet());
                          tcp = packet.getHeader(new Tcp());
                          eth.source(source_MAC);
                          ip.source(source_IP); 
                          // the source IP address is copied to a byte array
                          ip.destination(new byte[] {(byte)192,(byte)168,0,30}); // the user-defined destination IP address is written to a  byte array
                          eth.destination(new byte [] {(byte)54,(byte)35,(byte)30,(byte)71,(byte)3D,(byte)8F});
                          ip.checksum(ip.calculateChecksum());// the checksum is re-calculated
                          tcp.destination(80);
                          tcp.checksum(tcp.calculateChecksum());
                          pcap.sendPacket(new byte [] {(byte)192,(byte)168,0,30}); //the packet is sent to the user-defined IP address
                          packet.scan(Ethernet.ID); // End of packet modification
                          // If the packet cannot be sent, output error
                           if (pcap.sendPacket(packet) != Pcap.OK){
                              System.err.println(pcap.getErr());
                           }
                          }
/*****************************TCP port 80 scan end********************************/
/*****************************TCP port 23 scan initiation********************************/
                          else if (tcp.source() == 23){
                              System.out.println("Telnet packet captured");
                              System.out.println("The Destination selected is : "+Destination_IP); 
                              String Source_Sub_String1 = Source_IP.substring(0,10);
                              if ("192.168.1.".equals(Source_Sub_String1) ){
                                System.out.println("Telnet connection initialted with the external host");
                              }//if the telnet request comes from external host, the packet is redirected.
                              else{
                                 packet.scan(Ethernet.ID); //Start Packet Modification, scan the packet details
                                  ip = packet.getHeader(new Ip4());
                                  eth = packet.getHeader(new Ethernet());
                                  tcp = packet.getHeader(new Tcp());
                                  eth.source(source_MAC);
                                  ip.source(source_IP); // the source IP address is copied to a byte array
                                  ip.destination(new byte[] {(byte)192,(byte)168,1,12}); // the user-defined destination IP address is written to a  byte array
                                  eth.destination(new byte [] {(byte)54,(byte)35,(byte)30,(byte)71,(byte)3D,(byte)8F});
                                  ip.checksum(ip.calculateChecksum());// the checksum is re-calculated
                                  tcp.destination(23);
                                  tcp.checksum(tcp.calculateChecksum());
                                  pcap.sendPacket(new byte [] {(byte)192,(byte)168,1,12}); //the packet is sent to the user-defined IP address
                                  packet.scan(Ethernet.ID); // End of packet modification
                                  // If the packet cannot be sent, output error
                                  if (pcap.sendPacket(packet) != Pcap.OK){
                                        System.err.println(pcap.getErr());
                                    }
                              }   
                          }
/*****************************TCP port 80 scan end********************************/
/*****************************TCP port 25 scan initiation********************************/
                          else if (tcp.source() == 25){
                              System.out.println("SMTP packets captured");                                    
                              String Destination_Sub_String_Internal_network = Destination_IP.substring(0, 12); 
                              String Source_Sub_String_Internal_network = Source_IP.substring(0, 10);
                              String Destination_Sub_String_External_network = Destination_IP.substring(0, 12);
                              String Source_Sub_String_External_network = Source_IP.substring(0, 12);
                              //sub-strings declared with size 12 and IP addresses in the respective sub-strings are scanned
                               if ("192.168.1.30".equals(Destination_Sub_String_Internal_network)
                                || "192.168.1".equals(Source_Sub_String_Internal_network)
                                || "192.168.1.30".equals(Destination_Sub_String_Internal_network)
                                || "192.168.1".equals(Source_Sub_String_Internal_network))
                               {
                                   System.out.println("The mail passed to the mail server");
                               }
                               //sub-strings declared with size 12 and IP addresses in the respective sub-strings are scanned
                               else if ("192.168.1.30".equals(Destination_Sub_String_External_network) 
                                     || "".equals(Source_Sub_String_External_network)
                                     || "192.168.1.30".equals(Source_Sub_String_External_network) 
                                     || "".equals(Destination_Sub_String_External_network))
                               {
                                   System.out.println("The mail passed to the mail server");
                               }
                             else{
                                  packet.scan(Ethernet.ID); //Start Packet Modification, scan the packet details
                                  ip = packet.getHeader(new Ip4());
                                  eth = packet.getHeader(new Ethernet());
                                  tcp = packet.getHeader(new Tcp());
                                  eth.source(source_MAC);
                                  ip.source(source_IP);
                                  ip.destination(new byte[] {(byte)192,(byte)168,1,12}); // the user-defined destination IP address is written to a  byte array
                                  eth.destination(new byte [] {(byte)54,(byte)35,(byte)30,(byte)71,(byte)3D,(byte)8F});
                                  ip.checksum(ip.calculateChecksum());// the checksum is re-calculated
                                  tcp.destination(25);
                                  tcp.checksum(tcp.calculateChecksum());
                                  pcap.sendPacket(new byte [] {(byte)192,(byte)168,1,12}); //the packet is sent to the user-defined IP address
                                  packet.scan(Ethernet.ID); // End of packet modification
                                  if (pcap.sendPacket(packet) != Pcap.OK) {
                                        System.err.println(pcap.getErr()); // If the packet cannot be sent, output error
                                    } 
                              }
                          }     
                      }
/*****************************TCP port 80 scan end********************************/
/******************************end of TCP packet capture **************************/                  
/*****************************Start of UDP packet modification********************************/
                         else if (packet.hasHeader(udp)){ //IP section of a message
                            System.out.println("UDP packet has been captured");
                            source_IP = packet.getHeader(ip).source();
                            String Source_IP = org.jnetpcap.packet.format.FormatUtils.ip(source_IP);
                            destination_IP = packet.getHeader(ip).destination();
                            String Destination_IP = org.jnetpcap.packet.format.FormatUtils.ip(destination_IP);
                            //MAC address section of a message
                            source_MAC = packet.getHeader(eth).source();
                            String Source_MAC = org.jnetpcap.packet.format.FormatUtils.mac(source_MAC);
                            destination_MAC = packet.getHeader(eth).destination();
                            String Destination_MAC = org.jnetpcap.packet.format.FormatUtils.mac(destination_MAC);
                            System.out.println(" Source IP : "+Source_IP
                                             + " Destination IP : "+Destination_IP
                                             + " Source MAC Address : "+Source_MAC
                                             + " Destination MAC Address : "+Destination_MAC
                                             + " UDP port : "+udp.source());
                          if (udp.source() == 53){
                              System.out.println("A DNS Server query packet captured"); 
                          }
                          else if (udp.source() !=53){
                           packet.scan(Ethernet.ID); //Start Packet Modification, scan the packet details
                           ip = packet.getHeader(new Ip4());
                           eth = packet.getHeader(new Ethernet());
                           udp = packet.getHeader(new Udp());
                           eth.source(source_MAC);
                           ip.source(source_IP); // the source IP address is copied to a byte array
                           ip.destination(new byte[] {(byte)192,(byte)168,1,12}); // the user-defined destination IP address is written to a  byte array
                           eth.destination(new byte [] {(byte)54,(byte)35,(byte)30,(byte)71,(byte)3D,(byte)8F});
                           ip.checksum(ip.calculateChecksum());// the checksum is re-calculated
                           pcap.sendPacket(new byte [] {(byte)192,(byte)168,1,12}); //the packet is sent to the user-defined IP address
                           packet.scan(Ethernet.ID); // End of packet modification
                           // If the packet cannot be sent, output error
                           if (pcap.sendPacket(packet) != Pcap.OK){
                             System.err.println(pcap.getErr());
                           } 
                         }
                       }
                      /*****************************end of UDP packet modification********************************/  
                      /*****************************Start of ICMP packet modification********************************/
                        else if(packet.hasHeader(icmp)){
                           System.out.println("An ICMP packet has been captured:"); //IP layer of a message
                           source_IP = packet.getHeader(ip).source();
                           String Source_IP = org.jnetpcap.packet.format.FormatUtils.ip(source_IP);
                           destination_IP = packet.getHeader(ip).destination();
                           String Destination_IP = org.jnetpcap.packet.format.FormatUtils.ip(destination_IP);
                           //MAC address layer of a message
                           source_MAC = packet.getHeader(eth).source();
                           String Source_MAC = org.jnetpcap.packet.format.FormatUtils.mac(source_MAC);
                           destination_MAC = packet.getHeader(eth).destination();
                           String Destination_MAC = org.jnetpcap.packet.format.FormatUtils.mac(destination_MAC);
                           System.out.println(" Source IP : "+Source_IP
                                            + " Destination IP : "+Destination_IP
                                            + " Source MAC Address : "+Source_MAC
                                            + " Destination MAC Address : "+Destination_MAC 
                                            + "ICMP packet type : " +icmp.typeDescription());
                           // destination unreachable
                           Icmp.DestinationUnreachable unreachable_destination = new Icmp.DestinationUnreachable();
                           icmp.hasSubHeader(unreachable_destination);
                           // end of destination unreachable
                           // echo request
                           Icmp.EchoRequest echo_request = new Icmp.EchoRequest();
                           icmp.hasSubHeader(echo_request);
                           // end of echo request
                           //echo reply
                           Icmp.EchoReply echo_reply = new Icmp.EchoReply();
                           icmp.hasSubHeader(echo_reply);
                           // end of echo reply
                           //ICMP rediect
                           Icmp.Redirect redirect = new Icmp.Redirect();
                           icmp.hasSubHeader(redirect);
                           // end of ICMP redirect
                         if (icmp.hasSubHeader(unreachable_destination)){
                             System.out.println("ICMP Destination unreachable packet captured" );
                         }
                         else if (icmp.hasSubHeader(echo_request)){
                           System.out.println("ICMP echo request packet captured");
                           packet.scan(Ethernet.ID); //Start Packet Modification, scan the packet details
                           icmp = packet.getHeader(new Icmp());
                           eth = packet.getHeader(new Ethernet());
                           eth.source(source_MAC);
                           ip.source(source_IP); // the source IP address is copied to a byte array
                           ip.destination(new byte[] {(byte)192,(byte)168,1,12}); // the user-defined destination IP address is written to a  byte array
                           eth.destination(new byte [] {(byte)54,(byte)35,(byte)30,(byte)71,(byte)3D,(byte)8F});
                           ip.checksum(ip.calculateChecksum());// the checksum is re-calculated
                           pcap.sendPacket(new byte [] {(byte)192,(byte)168,1,12}); //the packet is sent to the user-defined IP address
                           packet.scan(Ethernet.ID); // End of packet modification
                           // If the packet cannot be sent, output error
                           if (pcap.sendPacket(packet) != Pcap.OK){
                             System.err.println(pcap.getErr());
                           }   
                             packet.scan(Ethernet.ID); //Start Packet Modification, scan the packet details
                             icmp = packet.getHeader(new Icmp());
                             ip = packet.getHeader(new Ip4());
                            //Editing the Ip layer
                             eth = packet.getHeader(new Ethernet());
                             ip.source(source_IP); 
                             eth.source(source_MAC);
                             // the modified MAC address
                             eth.destination(new byte [] {(byte)54,(byte)35,(byte)30,(byte)71,(byte)3D,(byte)8F});
                             ip.destination(new byte[] {(byte)192,(byte)168,0,3});
                             ip.checksum(ip.calculateChecksum());
                             pcap.sendPacket(new byte [] {(byte)192,(byte)168,0,3}); //the IP address the packet to be forwarded   
                             packet.scan(Ethernet.ID); // End of packet modification 
                         }
                      else if (icmp.hasSubHeader(echo_reply)){
                          System.out.println("ICMP echo reply packet captured");
                      }        
                      else if (icmp.hasSubHeader(redirect)){
                        System.out.println("ICMP redirect packet captured");
                      }
                      /*****************************end of ICMP packet modification********************************/
                      }  
                      /*****************************start of other packet redirection********************************/
                        else{
                            System.out.println("The captured packet is not allowed through the firewall");
                            packet.scan(Ethernet.ID);//Start Packet Modification, scan the packet details
                          ip = packet.getHeader(new Ip4());
                          eth = packet.getHeader(new Ethernet());
                          tcp = packet.getHeader(new Tcp());
                          eth.source(source_MAC);
                          ip.source(source_IP);// the source IP address is copied to a byte array
                          ip.destination(new byte[] {(byte)192,(byte)168,1,12}); // the user-defined destination IP address is written to a  byte array
                          eth.destination(new byte [] {(byte)54,(byte)35,(byte)30,(byte)71,(byte)3D,(byte)8F});
                          ip.checksum(ip.calculateChecksum());// the checksum is re-calculated
                          tcp.destination(80);
                          tcp.checksum(tcp.calculateChecksum());
                          pcap.sendPacket(new byte [] {(byte)192,(byte)168,1,12}); //the packet is sent to the user-defined IP address
                          packet.scan(Ethernet.ID); // End of packet modification
                          // If the packet cannot be sent, output error
                           if (pcap.sendPacket(packet) != Pcap.OK){
                              System.err.println(pcap.getErr());
                           }
                            System.out.println("Packeet re-directed to the offline dump");
                        }
                   } 
            	} ;
          pcap.loop(100, handler,null);//the Pcap Handler is looped
          pcap.loop(100, dumpHandler, dumper);// the Pcap Dumper is looped
    File file = new File(output_file);  
    // a new file created with the name output_file function to save the Pcap dump
    System.out.printf("%s file has %d bytes in it!\n", output_file, file.length()); 
        System.out.println("The dump file has been saved");
            pcap.close();    //Close the pcap   
    }
    
    public static String MAC_Address_to_String (byte [] MAC_Address){
        StringBuilder buffer_String = new StringBuilder(); 
        for (byte byte_size : MAC_Address) { 
            if (buffer_String.length() != 0){ 
                buffer_String.append(':'); 
            } 
            if (byte_size >= 0 && byte_size < 16){ 
                buffer_String.append('0'); 
            } 
        buffer_String.append(Integer.toHexString((byte_size < 0) ? byte_size + 256 : byte_size).toUpperCase()); 
        } 
 // a public class declared to print the MAC address in String format. the read MAC address is 
        //passed down to the function in byte form
  return buffer_String.toString(); 
    }
}